# Firebase Android | Serie

Repositorio con el código fuente de los videos de explicación con la integración de Firebase en Android con Kotlin y Jetpack Compose, los cuáles se encuentran en el canal de [DevExpert en YouTube](https://www.youtube.com/@devexpert_io/videos).

### Videos:

| [![YouTube](https://img.youtube.com/vi/fKESOlJmKGY/0.jpg)](https://www.youtube.com/watch?v=fKESOlJmKGY "YouTube") |  |
| ------------- |:-------------:|
