package io.devexpert.android_firebase.model

data class Contact(
    val key: String? = null,
    val name: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val uid: String = ""
)